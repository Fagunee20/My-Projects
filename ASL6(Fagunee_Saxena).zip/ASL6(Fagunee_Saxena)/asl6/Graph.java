package asl6;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;


public class Graph implements I_Graph
{
    private List<Node> Nodes;
    private List<List<Integer>> edges;
    private int nextNodeId;

    public Graph()
    {
        this.Nodes = new ArrayList<>();
        this.edges = new ArrayList<>();
        this.nextNodeId = 0;

    }

    @Override
    public int newNode(int x, int y) 
    {
        for (Node node : Nodes) 
        {
            if (node.x == x && node.y == y) 
            {
                throw new IllegalArgumentException("Node with the same coordinates already exists.");
            }
        }
        Node newNode = new Node(x, y, nextNodeId);
        Nodes.add(newNode);
        edges.add(new ArrayList<>());
        nextNodeId++;
        return newNode.id;
        
    }

    @Override
    public boolean setEdge(int from, int to) 
    {
        if (from < 0 || from >= Nodes.size() || to < 0 || to >= Nodes.size()) 
        {
            return false;
        }
        if (from == to) 
        {
            return false;
        }
        if (!edges.get(from).contains(to)) 
        {
            edges.get(from).add(to);
            edges.get(to).add(from);
            return true;
        }
        return false;
    }

    @Override
    public List<List<Integer>> getEdges() 
    {
        return edges;
    }

    @Override
    public boolean areNeighbors(int firstNode, int secondNode) 
    {
        if (firstNode < 0 || firstNode >= Nodes.size() || secondNode < 0 || secondNode >= Nodes.size()) 
        {
            return false;
        }
        return edges.get(firstNode).contains(secondNode);
    }

    public List<List<Integer>> getnGons(int n) 
    {
        List<List<Integer>> ngons = new ArrayList<>();
        for (int i = 0; i < Nodes.size(); i++) 
        {
            List<Integer> ngon = new ArrayList<>();
            ngon.add(i);
            Set<Integer> visited = new HashSet<>();
            visited.add(i);
            findNGon(i, n, ngon, visited, ngons);
        }
        return ngons;
    }

    @Override
    public List<List<Integer>> getNGons(int n) 
    {
        List<List<Integer>> ngons = new ArrayList<>();
        for (int i = 0; i < Nodes.size(); i++) 
        {
            List<Integer> ngon = new ArrayList<>();
            ngon.add(i);
            Set<Integer> visited = new HashSet<>();
            visited.add(i);
            findNGon(i, n, ngon, visited, ngons);
        }
        return ngons;
    }
    private void findNGon(int current, int n, List<Integer> ngon, Set<Integer> visited, List<List<Integer>> ngons) 
    {
        if (ngon.size() == n) 
        {
            if (edges.get(current).contains(ngon.get(0))) 
            {
                ngons.add(new ArrayList<>(ngon));
            }
            return;
        }
        for (int neighbor : edges.get(current)) 
        {
            if (!visited.contains(neighbor)) 
            {
                visited.add(neighbor);
                ngon.add(neighbor);
                findNGon(neighbor, n, ngon, visited, ngons);
                ngon.remove(neighbor);
                visited.remove(neighbor);
            }
        }
    }

    @Override
    public List<Integer> getLongestPath(int from, int to) 
    {
        if (from < 0 || from >= Nodes.size() || to < 0 || to >= Nodes.size()) 
        {
            return new ArrayList<>();
        }
        if (from == to) 
        {
            return new ArrayList<>();
        }
        Map<Integer, Integer> distances = new HashMap<>();
        Map<Integer, Integer> predecessors = new HashMap<>();
        Queue<Integer> queue = new LinkedList<>();
        queue.offer(from);
        distances.put(from, 0);
        while (!queue.isEmpty()) 
        {
            int current = queue.poll();
            for (int neighbor : edges.get(current)) 
            {
                if (!distances.containsKey(neighbor)) 
                {
                    distances.put(neighbor, distances.get(current) + 1);
                    predecessors.put(neighbor, current);
                    queue.offer(neighbor);
                }
            }
        }
        if (!distances.containsKey(to)) 
        {
            return new ArrayList<>();
        }
        List<Integer> path = new ArrayList<>();
        int current = to;
        while (current != from) 
        {
            path.add(current);
            current = predecessors.get(current);
        }
        path.add(from);
        Collections.reverse(path);
        return path;
    }
        
    @Override
    public Graph getNonCrossingGraph() 
    {
        Graph newGraph = new Graph();
        for (Node node : Nodes) 
        {
            newGraph.newNode(node.x, node.y);
        }
        for (int i = 0; i < Nodes.size(); i++) 
        {
            for (int j = i + 1; j < Nodes.size(); j++) 
            {
                if (edges.get(i).contains(j)) 
                {
                    Node node1 = Nodes.get(i);
                    Node node2 = Nodes.get(j);
                    if (intersects(node1, node2)) 
                    {
                        int newNodeId = newGraph.newNode((node1.x + node2.x) / 2, (node1.y + node2.y) / 2);
                        newGraph.setEdge(node1.id, newNodeId);
                        newGraph.setEdge(node2.id, newNodeId);
                    } else 
                    {
                        newGraph.setEdge(i, j);
                    }
                }
            }
        }
        return newGraph;
    }
    private boolean intersects(Node node1, Node node2) 
    {
        for (int i = 0; i < Nodes.size(); i++) 
        {
            for (int j = i + 1; j < Nodes.size(); j++) 
            {
                if (i != node1.id && i != node2.id && j != node1.id && j != node2.id) 
                {
                    if (edges.get(i).contains(j)) 
                    {
                        Node node3 = Nodes.get(i);
                        Node node4 = Nodes.get(j);
                        if (linesIntersect(node1.x, node1.y, node2.x, node2.y, node3.x, node3.y, node4.x, node4.y)) 
                        {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    private boolean linesIntersect(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4) 
    {
        double denom = ((x1 - x2) * (y3 - y4)) - ((y1 - y2) * (x3 - x4));
        if (denom == 0) 
        {
            return false; // Lines are parallel
        }
        double ua = (((x3 - x4) * (y1 - y3)) - ((y3 - y4) * (x1 - x3))) / denom;
        double ub = (((x1 - x2) * (y1 - y3)) - ((y1 - y2) * (x1 - x3))) / denom;
        if (ua >= 0 && ua <= 1 && ub >= 0 && ub <= 1) 
        {
            return true; // Lines intersect
        }
        return false; // Lines do not intersect
    }
    private static class Node 
    {
        int x;
        int y;
        int id;

        public Node(int x, int y, int id) 
        {
            this.x = x;
            this.y = y;
            this.id = id;
        }
    }
}


