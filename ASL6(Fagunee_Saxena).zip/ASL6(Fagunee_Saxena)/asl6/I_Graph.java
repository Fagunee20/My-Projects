package asl6;

import java.util.List;

public interface I_Graph {
    int newNode(int x, int y);
    boolean setEdge(int from, int to);
    List<List<Integer>> getEdges();
    boolean areNeighbors(int firstNode, int secondNode);
    List<List<Integer>> getNGons(int n);
    List<Integer> getLongestPath(int from, int to);
    Graph getNonCrossingGraph();
}
